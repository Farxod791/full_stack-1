
export const users = [
  {
    id: 1,
    username: "Ali",
    surname: "Karimov",
    email: "ali.karimov@gmail.com",
    password: "ali1234",
    personality: "jismoniy",
    company: null,
    requests: []
  },
  {
    id: 2,
    username: "Dilshod",
    surname: "Rasulov",
    email: "dilshod.rasulov@mail.uz",
    password: "dilshod456",
    personality: "jismoniy",
    company: null,
    requests: [
      {
        problem: "Printer ishlamayapti",
        response: { days: 1, price: 50000 }
      }
    ]
  },
  {
    id: 3,
    username: "Shahnoza",
    surname: "Ortiqova",
    email: "shahnoza@itworld.uz",
    password: "shahnoza789",
    personality: "yuridik",
    company: "IT World LLC",
    requests: []
  },
  {
    id: 4,
    username: "Azizbek",
    surname: "Hamroyev",
    email: "azizbek.hamroyev@company.uz",
    password: "aziz123",
    personality: "yuridik",
    company: "TechnoPark MCHJ",
    requests: [
      {
        problem: "Serverda xatolik chiqdi",
        response: { days: 3, price: 250000 }
      }
    ]
  },
  {
    id: 5,
    username: "Gulnoza",
    surname: "Xolmatova",
    email: "gulnoza.x@gmail.com",
    password: "gulnoza2024",
    personality: "jismoniy",
    company: null,
    requests: []
  },
  {
    id: 6,
    username: "Rustam",
    surname: "Nazarov",
    email: "rustam@devs.uz",
    password: "rustam321",
    personality: "yuridik",
    company: "Devs Team",
    requests: [
      {
        problem: "Kod kompilyatsiya qilinmayapti",
        response: { days: 2, price: 180000 }
      }
    ]
  },
  {
    id: 7,
    username: "Malika",
    surname: "Solieva",
    email: "malika.solieva@mail.uz",
    password: "malika007",
    personality: "jismoniy",
    company: null,
    requests: []
  },
  {
    id: 8,
    username: "Sardor",
    surname: "Yusupov",
    email: "sardor@financegroup.uz",
    password: "sardor555",
    personality: "yuridik",
    company: "Finance Group",
    requests: [
      {
        problem: "1C dasturi ochilmayapti",
        response: { days: 2, price: 120000 }
      }
    ]
  },
  {
    id: 9,
    username: "Mohira",
    surname: "Tursunova",
    email: "mohira@gmail.com",
    password: "mohira111",
    personality: "jismoniy",
    company: null,
    requests: [
      {
        problem: "1C dasturi ochilmayapti",
      },
      {
        problem: "1C dasturi ochilmayapti",
      }
    ]
  },
  {
    id: 10,
    username: "Jamshid",
    surname: "Islomov",
    email: "jamshid@elektro.uz",
    password: "jamshid999",
    personality: "yuridik",
    company: "Elektro Systems",
    requests: []
  },
  {
  id: 15,
  username: "Sherzod",
  surname: "Mirzayev",
  email: "sherzod@mastertech.uz",
  password: "securepass2025",
  personality: "master",
  company: null,
  requests: []
},
{
  id: 16,
  username: "Nodira",
  surname: "Ahmedova",
  email: "nodira@admin.uz",
  password: "adminsecure2025",
  personality: "admin",
  company: null,
  requests: []
}
];


